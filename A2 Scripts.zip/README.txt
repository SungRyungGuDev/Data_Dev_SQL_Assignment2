Execute the scripts in the following order:

1. create_wkis.sql
2. constraints_wkis.sql
3. load_wkis.sql
4. A1_test dataset_1 - Clean.sql
	OR
4. A1_test dataset_2 - Clean and Erroneous.sql



